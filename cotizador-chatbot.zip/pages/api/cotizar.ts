export default function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();
  const body = req.body;
  const edad = parseInt(body[2]);
  const modelo = body[0];
  const siniestros = body[3]?.toLowerCase().includes("sí");
  const cp = body[1];

  let base = 350;
  if (edad < 25) base += 150;
  if (siniestros) base += 200;
  if (modelo.includes("BMW") || modelo.includes("Audi")) base += 100;
  if (cp.startsWith("28")) base -= 30;

  res.status(200).json({ precio: Math.round(base) });
}
