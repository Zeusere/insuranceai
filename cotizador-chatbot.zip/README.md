# Cotizador de Seguros – Chatbot MVP

Proyecto en Next.js + Tailwind que ofrece un chatbot interactivo para cotizar seguros de coche en España.

## Instalación

```bash
npm install
npm run dev
```

## Despliegue

Sube este repositorio a GitHub y conéctalo en Vercel para desplegar automáticamente.
